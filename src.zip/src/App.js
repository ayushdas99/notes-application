import React from "react";


import NotesList from "./components/NotesList";
import Search from "./components/Search";
import Header from "./components/Header";
import About from "./Component/About";
import Home from "./Component/Home";
import Contact from "./Component/Contact";
import User from "./Component/User";
import Users from "./Component/Users";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Main from "./Component/Main";

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Main />} />
      <Route path="/home" element={<Home />} />
      <Route path="/about" exact element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/:name" element={<User />} />
      <Route path="/users" element={<Users />} />
    </Routes>
  );
};

export default App;