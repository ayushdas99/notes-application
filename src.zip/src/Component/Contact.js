import React from "react";

export default function Contact() {
    return(
        <div className="contact">
        <h1>Contact us</h1>
        <h2>Ayush Das</h2>
        <span>ayushd99@gmail.com</span>
        </div>
    )
    
}