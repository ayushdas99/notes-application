import React from "react";
import { useParams } from "react-router-dom";


export default function User() {
    const {name}  = useParams();
    return(
        <h2>Welcome to our page , {name} </h2>
    )
};
