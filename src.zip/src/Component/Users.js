import React from "react";
import { useSearchParams } from "react-router-dom";

const users = ['Ayush', 'Akshat', 'Rajat', 'Mary', 'Jay', 'Prince', 'Vikas', 'Vaibhav', 'Rohan']

export default function Users() {

    const[searchParams, setSearchParams] = useSearchParams();
 
   const searchTerm = searchParams.get('name') || '';

   const handleSearch = event => {
    const name = event.target.value;
    if(name) {
        setSearchParams({name});
    }
    else{
        setSearchParams({});
    }
}
 


    return(
        <div>
       <h1>Search Users</h1>
       <input type="text" value={searchTerm} onChange={handleSearch}/>
       <ul>
           {users
           .filter(user => user.toLowerCase().includes(searchTerm.toLowerCase()))
           .map((user,i) => (
               <li key={i}>{user}</li>
           ))
          
           }
       </ul>
   </div>

    )
    
}